/*!
    \file  main.c
    \brief led spark and key scan demo
    
    \version 2018-03-26, V1.0.0, demo for GD32F3x0
*/

/*
    Copyright (c) 2018, GigaDevice Semiconductor Inc.

    All rights reserved.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#include "gd32f3x0.h"
#include "gd32f3x0_eval.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include <stdio.h>

#define INIT_TASK_PRIO    ( tskIDLE_PRIORITY + 1 )
#define LED2_TASK_PRIO    ( tskIDLE_PRIORITY + 2 )
#define KEY4_TASK_PRIO    ( tskIDLE_PRIORITY + 2 )
 
 
void led2_task(void * pvParameters); 
void key4_task(void * pvParameters);
void init_task(void * pvParameters);

/* Binary semaphore handle definition. */
SemaphoreHandle_t binary_semaphore;

/*!
    \brief      main function
    \param[in]  none
    \param[out] none
    \retval     none
*/
int main(void)
{
    /* configure 4 bits pre-emption priority */
    nvic_priority_group_set(NVIC_PRIGROUP_PRE4_SUB0);

    /* init task */
    xTaskCreate(init_task, "INIT", configMINIMAL_STACK_SIZE, NULL, INIT_TASK_PRIO, NULL);
    
    /* start scheduler */
    vTaskStartScheduler();

    while (1)
	{
    }
}

/*!
    \brief      init task
    \param[in]  pvParameters not used
    \param[out] none
    \retval     none
*/
void init_task(void *pvParameters)
{
    gd_eval_key_init(KEY_TAMPER, KEY_MODE_EXTI);
    gd_eval_com_init(USART0);
    gd_eval_led_init(LED2);
    gd_eval_led_on(LED2);
    gd_eval_led_init(LED3);
    gd_eval_led_off(LED3);
    /* create a binary semaphore. */
    binary_semaphore = xSemaphoreCreateBinary();

    /* start toogle LED2 task */
    xTaskCreate(led2_task, "LED2", configMINIMAL_STACK_SIZE, NULL, LED2_TASK_PRIO, NULL);
    /* start KEY4 scan task */
    xTaskCreate(key4_task, "KEY4", configMINIMAL_STACK_SIZE, NULL, KEY4_TASK_PRIO, NULL);
    for( ;; )
	{
        vTaskDelete(NULL);
    }
}

/*!
    \brief      LED2 task
    \param[in]  pvParameters not used
    \param[out] none
    \retval     none
*/
void led2_task(void * pvParameters)
{  
    for( ;; )
	{
        /* toggle LED2 each 500ms */
        gd_eval_led_toggle(LED2);
        vTaskDelay(500);
    }
}

/*!
    \brief      LED4 task
    \param[in]  pvParameters not used
    \param[out] none
    \retval     none
*/
void key4_task(void * pvParameters)
{  
    BaseType_t err = pdFALSE;
    for( ;; )
	{
        if(NULL != binary_semaphore)
		{
            err = xSemaphoreTake(binary_semaphore, portMAX_DELAY);
            if(pdTRUE == err)
			{
                gd_eval_led_toggle(LED3);
//				xSemaphoreGive(MutexSemaphore);
                printf("The key of Temper is pressed.\r\n");
            }
        }
        else if(pdFALSE == err)
		{
            vTaskDelay(10);      
        }
    }
}

/* retarget the C library printf function to the USART */
int fputc(int ch, FILE *f)
{
    usart_data_transmit(USART0, (uint8_t) ch);
    while (RESET == usart_flag_get(USART0, USART_FLAG_TBE));
    return ch;
}
